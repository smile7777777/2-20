% Load input data
load inputdata.mat

% Assume 'load inputdata.mat' has loaded a variable 'packet'
% Define polynomial C
C = [1 0 0 0 0 0 1 0 0 1 1 0 0 0 0 0 1 0 0 0 1 1 1 0 1 1 0 1 1 0 1 1 1];

% Initialize CRC remainder calculation
R = zeros(1, 32);
tmp = zeros(1, 33);
tmp(1:33) = packet(1:33);
packet = [packet, zeros(1, 32)];  % Extend packet with zeros for CRC

% Perform CRC encoding
for i = 1:12000
    tmp(33) = packet(i+32);
    if tmp(1) == 1
        R = xor(tmp(2:33), C(2:33));
    else
        R = tmp(2:33);
    end
    tmp(1:32) = R;
end

codepacket = [packet(1:12000), R];

% Parameters for error detection
N = 12032;  % Total length including extended zeros
start_index = 6001; 
found = false;
% 5869 5835 5821 0
% Manually iterate over possible combinations of four error indices
for i = 12032:N
    for j = 6211:6222
        for k = 6197:6212
            for l = start_index+162 :N
                error = zeros(1, N);
                R1 = ones(1, 32);

                % Introduce errors
                error([i, j, k, l]) = 1;

                % Simulate the error effect
                for x = start_index:N-32
                    if error(x) == 1
                        R1 = xor(error(x+1:x+32), C(2:33));
                        error(x+1:x+32) = R1;
                    end
                end

                % Check if error pattern results in zero checksum
                if sum(R1) == 0
                    disp('Found zero checksum with error positions:');
                    disp([i, j, k, l]);
                    found = true;
                    break;
                end
            end
            if found, break; end
        end
        if found, break; end
    end
    if found, break; end
end

if ~found
    disp('No error pattern found that results in zero checksum.');
end

save('u103060019.mat','codepacket','error');