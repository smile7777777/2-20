% Load input data
load inputdata.mat

% Assume 'load inputdata.mat' has loaded a variable 'packet'
% Define polynomial C
C = [1 0 0 0 0 0 1 0 0 1 1 0 0 0 0 0 1 0 0 0 1 1 1 0 1 1 0 1 1 0 1 1 1];

% Initialize CRC remainder calculation
R = zeros(1, 32);
tmp = zeros(1, 33);
tmp(1:33) = packet(1:33);
packet = [packet, zeros(1, 32)];  % Extend packet with zeros for CRC

% Perform CRC encoding
for i = 1:12000
    tmp(33) = packet(i+32);
    if tmp(1) == 1
        R = xor(tmp(2:33), C(2:33));
    else
        R = tmp(2:33);
    end
    tmp(1:32) = R;
end

codepacket = [packet(1:12000), R];

% Parameters for error detection
N = 12032;  % Total length including extended zeros
found = false;

%1, 2, 3 No Found
% Manually iterate over possible combinations of four error indices
for i = 1:N-3
    for j = i+1:12000
        for k = j+1:12000
            for l = k+1:N
                error = zeros(1, N);
                Rem = ones(1, 32);

                % Introduce errors
                error([N-i, N-j, N-k, N-l]) = 1;

                % Simulate the error effect
                for x = N-5869:N-32
                    if error(x) == 1
                        Rem = xor(error(x+1:x+32), C(2:33));
                        error(x+1:x+32) = Rem;
                    end
                end

                % Check if error pattern results in zero checksum
                if sum(Rem) == 0
                    disp('No Found');
                    disp([N-i, N-j, N-k, N-l]);
                    error(1:12032) = 0;
                    error(N-i) = 1; error(N-k) = 1;
                    error(N-j) = 1; error(N-l) = 1;
                    found = true;
                    break;
                end
            end
            if found, break; end
        end
        if found, break; end
    end
    if found, break; end
end

if ~found
    disp('No Found');
end
