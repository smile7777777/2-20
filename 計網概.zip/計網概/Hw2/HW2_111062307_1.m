load inputdata.mat

C = [1 0 0 0 0 0 1 0 0 1 1 0 0 0 0 0 1 0 0 0 1 1 1 0 1 1 0 1 1 0 1 1 1];
%    2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0;

R(1:32) = 0;
tmp(1:33) = packet(1:33);
packet(end+1:end+32) = 0;

for i = 1:12000
    tmp(33) = packet(i+32);
    if(tmp(1) == 1)
      R(1:32) = xor(tmp(2:33), C(2:33));
    elseif(tmp(1) == 0)
      R(1:32) = tmp(2:33);
    end
    tmp(1:32) = R(1:32);
end

codepacket = [packet(1:12000), R];

new_packet = codepacket;
new_packet(2) = xor(codepacket(2), 1);
new_packet(36) = xor(codepacket(36), 1);
new_packet(50) = xor(codepacket(50), 1);
new_packet(5871) = xor(codepacket(5871), 1);

R1(1:32) = 0;
tmp1(1:33) = new_packet(1:33);
for i = 1:12000
    tmp1(33) = new_packet(i+32);
    if(tmp1(1) == 1)
      R1(1:32) = xor(tmp1(2:33), C(2:33));
    elseif(tmp1(1) == 0)
      R1(1:32) = tmp1(2:33);
    end
    tmp1(1:32) = R1(1:32);
end