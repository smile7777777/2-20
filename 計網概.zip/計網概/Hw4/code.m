load('network_A.mat')
d = A;
sz = 100;

for distan = 2 : sz %dis to each node
    for i = 1 : sz %from which node
        for j = i+1 : sz %to which node
            if(A(i,j) == 0) %if i node and j node didn't have connection
                for k = 1 : sz
                    if(A(i, k) + A(k, j) == distan) %if k node between i node and j node and has the certain distance 
                        d(i, j) = distan; 
                        d(j, i) = distan;
                    end
                end
            end
        end
    end
    A = d;
end

save('result.mat','d');