load('network_A.mat');
tree = zeros(100, 100); %final answer
dis = zeros(1, 100); %disance to root
To_idx = zeros(1, 100); %from where

for d = 1 : 100
    for i = 1 : 100
        if (d == 1 && A(1, i) == 1)
            To_idx(i) = 1; % i's origin node = 1
            dis(i) = 1; % i's dis to 1
        elseif (d ~= 1 && dis(i) == d-1) %if distance = currrent distance
            for j = 1 : 100
                if(A(i,j) == 1 && To_idx(j) == 0) %i link with j and not link with 1
                    To_idx(j) = i;
                    dis(j) = d;
                end 
            end
        end
    end
end

%set value
for i = 1:100
    tree(i, To_idx(i)) = 1;
    tree(To_idx(i), i) = 1;
end

save('result.mat','tree');